import requests
import time
import os

def classify_sentiments(texts):
    if not texts: return []

    api_url = "https://api-inference.huggingface.co/models/distilbert-base-uncased-finetuned-sst-2-english"
    api_token = os.getenv("HF_API_TOKEN")
    headers = {"Authorization": f"Bearer {api_token}"}
    
    # បង្ហាញ Token បន្តិចដើម្បីឆែក (បង្ហាញតែ ៤ ខ្ទង់ដំបូងដើម្បីសុវត្ថិភាព)
    if api_token:
        print(f"--- កំពុងប្រើ Token ដែលផ្ដើមដោយ: {api_token[:4]}... ---")
    else:
        print("--- រកមិនឃើញ Token ទេ! សូមពិនិត្យមើល Environment Variable ---")

    for attempt in range(3):
        try:
            # បង្កើនការរង់ចាំឱ្យយូរជាងមុនបន្តិច ក្រែងលោ Model កំពុង Loading
            wait = [1, 3, 5] 
            time.sleep(wait[attempt])
            
            response = requests.post(api_url, headers=headers, json={"inputs": texts})
            
            if response.status_code == 200:
                results = response.json()
                return [res[0]['label'] for res in results]
            else:
                # បង្ហាញ Error ចេញមកក្រៅតែម្ដង
                print(f"ព្យាយាមលើកទី {attempt+1} បរាជ័យ: លេខកូដ {response.status_code}")
                print(f"សារពី API: {response.text}")
                
        except Exception as e:
            print(f"កំហុសបច្ចេកទេស: {e}")

    raise RuntimeError(f"Hugging Face API unavailable — {api_url}")

if __name__ == "__main__":
    texts = ["I love this!", "This is bad."]
    try:
        print(f"លទ្ធផល: {classify_sentiments(texts)}")
    except Exception as e:
        print(f"\n{e}")