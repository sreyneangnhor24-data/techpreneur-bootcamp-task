import pandas as pd
import os

def analyse_sales(filepath):
    
    if not os.path.exists(filepath) or os.stat(filepath).st_size == 0:
        return {}

    try:
        df = pd.read_csv(filepath)
        if df.empty:
            return {}

        df['date'] = pd.to_datetime(df['date'])
        df['revenue'] = df['units_sold'] * df['unit_price']
        df['month_name'] = df['date'].dt.month_name()

        results = {}

        for category, group in df.groupby('category'):
            ​
            best_month = group.groupby('month_name')['revenue'].sum().idxmax()
            
            results[category] = {
                'total_units_sold': int(group['units_sold'].sum()),
                'total_revenue': round(float(group['revenue'].sum()), 2),
                'avg_unit_price': round(float(group['unit_price'].mean()), 2),
                'best_month': best_month
            }
        return results
    except Exception as e:
        print(f"Error: {e}")
        return {}

# --- ផ្នែកសម្រាប់ Test កូដក្នុង VS Code ---
if __name__ == "__main__":
    # ហៅ function មកប្រើសាកមើល
    output = analyse_sales("sales.csv")
    import pprint
    pprint.pprint(output)