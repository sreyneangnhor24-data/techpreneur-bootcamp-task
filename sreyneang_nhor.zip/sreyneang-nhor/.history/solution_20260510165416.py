import requests
import time
import os

def classify_sentiments(texts):
    """
    អនុវត្តការវិភាគអារម្មណ៍ (Sentiment Analysis) ដោយប្រើ Hugging Face Inference API។
    """
    # ១. ពិនិត្យមើលបញ្ជីអត្ថបទ (Handle empty input list)
    if not texts:
        return []

    # ២. កំណត់ព័ត៌មាន API និង Endpoint URL
    model_id = "distilbert-base-uncased-finetuned-sst-2-english"
    api_url = f"https://api-inference.huggingface.co/models/{model_id}"
    
    # អាន API token ពី environment variable
    api_token = os.getenv("HF_API_TOKEN")
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json"
    }

    # ៣. ការរៀបចំសម្រាប់ Retry Logic និង Exponential Backoff
    max_attempts = 3
    # រង់ចាំ៖ 0ms (លើកទី១), 200ms (លើកទី២), 400ms (លើកទី៣)
    wait_times = [0, 0.2, 0.4] 

    for attempt_idx in range(max_attempts):
        try:
            # រង់ចាំមុននឹងព្យាយាម (Wait before retry)
            if wait_times[attempt_idx] > 0:
                time.sleep(wait_times[attempt_idx])
            
            # បញ្ជូន Request ទៅកាន់ API (Batch all texts in a single call)
            response = requests.post(
                api_url, 
                headers=headers, 
                json={"inputs": texts},
                timeout=10
            )

            # ពិនិត្យមើលថាតើការហៅ API ជោគជ័យឬទេ
            if response.status_code == 200:
                api_results = response.json()
                
                # ទាញយក Label (POSITIVE/NEGATIVE) ពីលទ្ធផលដែលទទួលបាន
                # API return រាងជា: [[{'label': 'POSITIVE', 'score': 0.99}], ...]
                final_labels = []
                for result in api_results:
                    # យក label ដែលមាន score ខ្ពស់ជាងគេ (ធាតុទី ០)
                    top_prediction = result[0]['label']
                    final_labels.append(top_prediction)
                
                return final_labels
            
            # បើ API មិនទាន់អាចប្រើបាន (Status code មិនមែន 200) យើងនឹងបន្តទៅ Loop បន្ទាប់
            
        except Exception:
            # បើមានកំហុសបច្ចេកទេស (Network error) យើងនឹងបន្តទៅ Loop បន្ទាប់
            pass

    # ៤. ប្រសិនបើការព្យាយាមទាំង ៣ ដងបរាជ័យ ត្រូវបោះ Error (Raise RuntimeError)
    raise RuntimeError(
        f"Hugging Face API unavailable after {max_attempts} attempts — {api_url}"
    )

# --- ផ្នែកសម្រាប់សាកល្បង (Test Block) ---
if __name__ == "__main__":
    # ចំណាំ៖ កុំភ្លេចកំណត់ $env:HF_API_TOKEN ក្នុង Terminal មុននឹង Run
    sample_texts = [
        'I absolutely love how intuitive this app feels.',
        'The model kept crashing and lost all my progress.',
        'Decent performance but the UI needs work.',
    ]
    
    try:
        results = classify_sentiments(sample_texts)
        print(f"Input Texts: {sample_texts}")
        print(f"Sentiment Results: {results}")
    except RuntimeError as error:
    print(f"Caught an error: {error}")