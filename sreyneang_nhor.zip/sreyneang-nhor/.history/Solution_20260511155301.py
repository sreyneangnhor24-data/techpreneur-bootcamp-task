import pandas as pd
import requests
import time
import os

def run_pipeline(filepath):
    # ត្រឡប់ dictionary ទទេ បើគ្មាន file ឬ file ទទេ [cite: 99]
    if not os.path.exists(filepath) or os.stat(filepath).st_size == 0:
        return {}

    try:
        df = pd.read_csv(filepath)
        # សម្អាតទិន្នន័យ 
        df = df.dropna(subset=['review_text'])
        df = df[df['review_text'].str.strip() != ""]

        if df.empty:
            return {}

        # ហៅប្រើ API ដើម្បី classify sentiments (ប្រើ logic ដូច Task 2)
        texts = df['review_text'].tolist()
        api_token = os.getenv("HF_API_TOKEN")
        api_url = "https://api-inference.huggingface.co/models/distilbert-base-uncased-finetuned-sst-2-english"
        headers = {"Authorization": f"Bearer {api_token}"}
        
        sentiments = []
        # អនុវត្ត retry logic ខ្លីៗដើម្បីធានាភាពសុក្រឹត [cite: 127]
        response = requests.post(api_url, headers=headers, json={"inputs": texts, "options": {"wait_for_model": True}})
        if response.status_code == 200:
            data = response.json()
            sentiments = [max(res, key=lambda x: x['score'])['label'] for res in data]
        
        df['sentiment'] = sentiments

        # គណនាស្ថិតិ [cite: 75, 76, 77, 78, 79]
        total = len(df)
        pos_count = len(df[df['sentiment'] == 'POSITIVE'])
        neg_count = len(df[df['sentiment'] == 'NEGATIVE'])

        by_product = {}
        for prod, group in df.groupby('product'):
            by_product[prod] = {
                'POSITIVE': len(group[group['sentiment'] == 'POSITIVE']),
                'NEGATIVE': len(group[group['sentiment'] == 'NEGATIVE'])
            }

        # Tie-breaking logic តាមអក្ខរក្រម [cite: 96, 97, 98]
        sorted_prods = sorted(by_product.keys())
        most_pos = max(sorted_prods, key=lambda x: by_product[x]['POSITIVE'])
        most_neg = max(sorted_prods, key=lambda x: by_product[x]['NEGATIVE'])

        return {
            'total_reviews': total,
            'positive_count': pos_count,
            'negative_count': neg_count,
            'sentiment_rate': {
                'POSITIVE': round((pos_count / total) * 100, 1),
                'NEGATIVE': round((neg_count / total) * 100, 1)
            },
            'by_product': by_product,
            'most_positive_product': most_pos,
            'most_negative_product': most_neg
        }
    except Exception:
        return {}