import requests
import time
import os

def classify_sentiments(texts):
    # ១. បើ list ទទេ ត្រូវ return list ទទេ (មិនហៅ API ទេ) [cite: 60]
    if not texts:
        return []

    # ២. ទាញយក API Token ពី Environment Variable 
    api_token = os.getenv("HF_API_TOKEN")
    model_id = "distilbert-base-uncased-finetuned-sst-2-english"
    api_url = f"https://api-inference.huggingface.co/models/{model_id}"
    
    headers = {"Authorization": f"Bearer {api_token}"}
    payload = {"inputs": texts, "options": {"wait_for_model": True}}

    # ៣. ការអនុវត្ត Retry Logic ជាមួយ Exponential Backoff [cite: 56, 57]
    max_attempts = 3
    for attempt in range(max_attempts):
        try:
            response = requests.post(api_url, headers=headers, json=payload)
            
            # បើជោគជ័យ (HTTP 200)
            if response.status_code == 200:
                data = response.json()
                # ស្រង់យក Label (POSITIVE/NEGATIVE) ដែលមានពិន្ទុខ្ពស់ជាងគេ
                results = []
                for prediction in data:
                    # prediction ជា list នៃ dictionary (ឧទាហរណ៍: [{'label': 'POSITIVE', 'score': 0.99}, ...])
                    best_label = max(prediction, key=lambda x: x['score'])['label']
                    results.append(best_label)
                return results
            
            # បើ API កំពុងរវល់ ឬមានបញ្ហាផ្សេងៗ
            if attempt < max_attempts - 1:
                wait_time = 0.2 * (2 ** attempt) # 200ms, 400ms [cite: 56]
                time.sleep(wait_time)
            else:
                # បើព្យាយាមអស់ ៣ ដងហើយនៅតែមិនបាន [cite: 55, 57]
                raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts {api_url}")
                
        except requests.exceptions.RequestException:
            if attempt < max_attempts - 1:
                time.sleep(0.2 * (2 ** attempt))
            else:
                raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts {api_url}")

    return []

# នាំចេញ function [cite: 62]
if __name__ == "__main__":
    pass