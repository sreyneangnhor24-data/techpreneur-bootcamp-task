import requests
import time
import os

def classify_sentiments(texts):
    """
    Classifies a list of texts into POSITIVE or NEGATIVE using Hugging Face API.
    """
    # 1. Handle empty input list [cite: 60]
    if not texts:
        return []

    # 2. Get API Token from environment variables [cite: 59]
    api_token = os.getenv("HF_API_TOKEN")
    model_id = "distilbert-base-uncased-finetuned-sst-2-english"
    api_url = f"https://api-inference.huggingface.co/models/{model_id}"
    
    headers = {"Authorization": f"Bearer {api_token}"}
    # 3. Batch all texts in a single API call [cite: 61]
    payload = {"inputs": texts, "options": {"wait_for_model": True}}

    # 4. Implement exponential backoff [cite: 56]
    max_attempts = 3
    for attempt in range(max_attempts):
        try:
            response = requests.post(api_url, headers=headers, json=payload)
            
            if response.status_code == 200:
                data = response.json()
                return [max(item, key=lambda x: x['score'])['label'] for item in data]
            
            if attempt < max_attempts - 1:
                wait_time = 0.2 * (2 ** attempt)
                time.sleep(wait_time)
            else:
                raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts {api_url}")
                
        except requests.exceptions.RequestException:
            if attempt < max_attempts - 1:
                time.sleep(0.2 * (2 ** attempt))
            else:
                raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts {api_url}")

    return []

if __name__ == "__main__":
    sample_texts = [
        "I absolutely love how intuitive this app feels.",
        "The model kept crashing and lost all my progress.",
        "Decent performance but the UI needs work."
    ]
    print("Results:", classify_sentiments(sample_texts))