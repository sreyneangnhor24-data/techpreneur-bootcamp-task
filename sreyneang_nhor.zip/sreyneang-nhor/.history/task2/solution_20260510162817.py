import requests
import time
import os

def classify_sentiments(texts):
    """
    វិភាគអារម្មណ៍ (Sentiment) នៃបញ្ជីអត្ថបទដោយប្រើ Hugging Face API។
    """
    # ១. ប្រសិនបើបញ្ជីអត្ថបទក្បាលទទេ មិនបាច់ហៅ API ទេ
    if not texts:
        return []

    # ២. កំណត់ព័ត៌មាន API
    model_id = "distilbert-base-uncased-finetuned-sst-2-english"
    api_url = f"https://api-inference.huggingface.co/models/{model_id}"
    
    # ទាញយក Token ពី Environment Variable (ហាមដាក់ Token ផ្ទាល់ក្នុងកូដ)
    api_token = os.getenv("HF_API_TOKEN")
    headers = {"Authorization": f"Bearer {api_token}"}
    
    # ៣. កំណត់ការព្យាយាមឡើងវិញ (Exponential Backoff)
    max_attempts = 3
    # ការរង់ចាំ៖ លើកទី១ (0ms), លើកទី២ (200ms), លើកទី៣ (400ms)
    wait_times = [0, 0.2, 0.4] 

    for attempt in range(max_attempts):
        try:
            # រង់ចាំមុននឹងព្យាយាម (លើកទី១ គឺរង់ចាំ 0 វិនាទី)
            time.sleep(wait_times[attempt])
            
            response = requests.post(
                api_url, 
                headers=headers, 
                json={"inputs": texts, "options": {"wait_for_model": True}}
            )
            
            # ប្រសិនបើជោគជ័យ (Status Code 200)
            if response.status_code == 200:
                results = response.json()
                # ទាញយកតែ Label (POSITIVE ឬ NEGATIVE) ពីលទ្ធផលនីមួយៗ
                # Hugging Face return មកជា list នៃ list: [[{'label': '...', 'score': ...}], ...]
                return [res[0]['label'] for res in results]
            
        except Exception:
            pass 

    raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts — {api_url}")

if __name__ == "__main__":
    sample_texts = [
        'I absolutely love how intuitive this app feels.',
        'The model kept crashing and lost all my progress.',
        'Decent performance but the UI needs work.'
    ]
    
    try:
        results = classify_sentiments(sample_texts)
        print(f"Results: {results}")
    except Exception as e:
        print(f"Error: {e}")