import requests
import time
import os

def classify_sentiments(texts):
    """
    Function សម្រាប់វិភាគអារម្មណ៍ (Sentiment Analysis) ដោយហៅប្រើ Hugging Face API [cite: 39, 40]
    """
    # ១. ត្រឡប់ list ទទេ បើគ្មានអត្ថបទបញ្ចូល [cite: 60]
    if not texts:
        return []

    # ២. ទាញយក API Token ពី Environment Variable (ហាម hard-code ក្នុងកូដ) [cite: 59]
    api_token = os.getenv("HF_API_TOKEN")
    model_id = "distilbert-base-uncased-finetuned-sst-2-english" [cite: 41]
    api_url = f"https://api-inference.huggingface.co/models/{model_id}"
    
    headers = {"Authorization": f"Bearer {api_token}"}
    # ប្រើ Batch request ដើម្បីផ្ញើអត្ថបទទាំងអស់ក្នុងពេលតែមួយ [cite: 61]
    payload = {"inputs": texts, "options": {"wait_for_model": True}}

    # ៣. អនុវត្ត Retry Logic ជាមួយ Exponential Backoff [cite: 56]
    max_attempts = 3
    for attempt in range(max_attempts):
        try:
            # ប្រើ requests សម្រាប់ HTTP calls (មិនប្រើ SDK) [cite: 58]
            response = requests.post(api_url, headers=headers, json=payload)
            
            if response.status_code == 200:
                data = response.json()
                # ស្រង់យក Label (POSITIVE ឬ NEGATIVE) ដែលមានពិន្ទុខ្ពស់ជាងគេ [cite: 41, 50]
                return [max(item, key=lambda x: x['score'])['label'] for item in data]
            
            # បើ API បរាជ័យ ត្រូវរង់ចាំតាម Exponential Backoff (200ms, 400ms) [cite: 56]
            if attempt < max_attempts - 1:
                wait_time = 0.2 * (2 ** attempt)
                time.sleep(wait_time)
            else:
                # បើព្យាយាមអស់ ៣ ដងនៅតែមិនបាន ត្រូវផ្ដល់ដំណឹងកំហុស [cite: 55, 57]
                raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts {api_url}")
                
        except requests.exceptions.RequestException:
            if attempt < max_attempts - 1:
                time.sleep(0.2 * (2 ** attempt))
            else:
                raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts {api_url}") [cite: 57]

    return []

# --- ផ្នែកសម្រាប់តេស្តលទ្ធផល (Test Section) ---
if __name__ == "__main__":
    # បញ្ជីអត្ថបទសម្រាប់សាកល្បង [cite: 43]
    sample_texts = [
        "I absolutely love how intuitive this app feels.",
        "The model kept crashing and lost all my progress.",
        "Decent performance but the UI needs work."
    ]
    
    print("--- កំពុងដំណើរការតេស្ត Task 2 ---")
    try:
        # ហៅ function មកប្រើ
        results = classify_sentiments(sample_texts)
        print("អត្ថបទបញ្ចូល:", sample_texts)
        print("លទ្ធផលវិភាគ:", results)
    except Exception as e:
        print("មានបញ្ហាកើតឡើង:", e)