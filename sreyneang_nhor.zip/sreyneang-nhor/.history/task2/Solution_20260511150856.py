import requests
import time
import os

def classify_sentiments(texts):
    if not texts:
        return []

    api_token = os.getenv("HF_API_TOKEN")
    model_id = "distilbert-base-uncased-finetuned-sst-2-english"
    api_url = f"https://api-inference.huggingface.co/models/{model_id}"
    
    headers = {"Authorization": f"Bearer {api_token}"}
    payload = {"inputs": texts, "options": {"wait_for_model": True}}

    max_attempts = 3
    for attempt in range(max_attempts):
        try:
            response = requests.post(api_url, headers=headers, json=payload)
            
            if response.status_code == 200:
                data = response.json()
                ​
                return [max(item, key=lambda x: x['score'])['label'] for item in data]
            
            # បើបរាជ័យ ត្រូវរង់ចាំតាម Exponential Backoff [cite: 56]
            if attempt < max_attempts - 1:
                time.sleep(0.2 * (2 ** attempt))
            else:
                raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts {api_url}") [cite: 55, 57]
                
        except requests.exceptions.RequestException:
            if attempt < max_attempts - 1:
                time.sleep(0.2 * (2 ** attempt))
            else:
                raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts {api_url}") [cite: 57]

    return []