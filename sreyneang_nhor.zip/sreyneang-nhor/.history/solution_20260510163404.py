import requests
import time
import os

def classify_sentiments(texts):
    if not texts:
        return []

    model_id = "distilbert-base-uncased-finetuned-sst-2-english"
    api_url = f"https://api-inference.huggingface.co/models/{model_id}"
    
    # ទាញយក Token
    api_token = os.getenv("HF_API_TOKEN")
    headers = {"Authorization": f"Bearer {api_token}"}
    
    max_attempts = 3
    wait_times = [0, 0.2, 0.4] 

    for attempt in range(max_attempts):
        try:
            time.sleep(wait_times[attempt])
            response = requests.post(api_url, headers=headers, json={"inputs": texts})
            
            if response.status_code == 200:
                results = response.json()
                return [res[0]['label'] for res in results]
            else:
                print(f"Attempt {attempt + 1}: Error {response.status_code} - {response.json()}")
            
        except Exception as e:
            print(f"Attempt {attempt + 1}: Connection error - {e}")

    raise RuntimeError(f"Hugging Face API unavailable after {max_attempts} attempts — {api_url}")

if __name__ == "__main__":
    test_texts = ['I love this!', 'I hate this!']
    try:
        print(f"Final Result: {classify_sentiments(test_texts)}")
    except Exception as e:
        print(f"\n: {e}")