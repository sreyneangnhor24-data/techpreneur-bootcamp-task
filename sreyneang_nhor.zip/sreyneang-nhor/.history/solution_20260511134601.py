import pandas as pd
import os
import requests
import time

# នាំចូល function ពី task 2
from task2.solution import classify_sentiments

def run_pipeline(filepath):
    
    if not os.path.exists(filepath) or os.stat(filepath).st_size == 0:
        return {}

    try:
        df = pd.read_csv(filepath)
        df = df.dropna(subset=['review_text'])
        if df.empty:
            return {}

        reviews = df['review_text'].tolist()
        sentiments = classify_sentiments(reviews)
        df['sentiment'] = sentiments

        total_reviews = len(df)
        pos_count = int((df['sentiment'] == 'POSITIVE').sum())
        neg_count = int((df['sentiment'] == 'NEGATIVE').sum())

        by_product = {}
        grouped = df.groupby('product')['sentiment'].value_counts().unstack(fill_value=0)
        
        for product, row in grouped.iterrows():
            by_product[product] = {
                'POSITIVE': int(row.get('POSITIVE', 0)),
                'NEGATIVE': int(row.get('NEGATIVE', 0))
            }

        # ៥. រកផលិតផលដែល Positive និង Negative ជាងគេ (ជាមួយលក្ខខណ្ឌអក្ខរក្រម)
        stats_df = grouped.reset_index()
        if 'POSITIVE' not in stats_df: stats_df['POSITIVE'] = 0
        if 'NEGATIVE' not in stats_df: stats_df['NEGATIVE'] = 0

        most_pos = stats_df.sort_values(by=['POSITIVE', 'product'], ascending=[False, True]).iloc[0]['product']
        most_neg = stats_df.sort_values(by=['NEGATIVE', 'product'], ascending=[False, True]).iloc[0]['product']

        return {
            'total_reviews': total_reviews,
            'positive_count': pos_count,
            'negative_count': neg_count,
            'sentiment_rate': {
                'POSITIVE': round((pos_count / total_reviews) * 100, 1),
                'NEGATIVE': round((neg_count / total_reviews) * 100, 1)
            },
            'by_product': by_product,
            'most_positive_product': most_pos,
            'most_negative_product': most_neg
        }
    except Exception:
        return {}

# សម្រាប់ Test
if __name__ == "__main__":
    # កុំភ្លេចបង្កើត reviews.csv ក្នុង folder task3
    print(run_pipeline("task3/reviews.csv"))